       // Mock data for the admin panel
        const mockData = {
            submissions: [
                { id: 'SUB-001', participant: 'Alex Johnson', activity: 'Robotics Workshop', date: '2023-10-15', status: 'approved', category: 'Technical' },
                { id: 'SUB-002', participant: 'Maria Garcia', activity: 'Debate Competition', date: '2023-10-14', status: 'pending', category: 'Cultural' },
                { id: 'SUB-003', participant: 'Raj Patel', activity: 'Hackathon', date: '2023-10-13', status: 'rejected', category: 'Technical' },
                { id: 'SUB-004', participant: 'Sarah Kim', activity: 'Music Festival', date: '2023-10-12', status: 'approved', category: 'Cultural' },
                { id: 'SUB-005', participant: 'David Chen', activity: 'Sports Day', date: '2023-10-11', status: 'pending', category: 'Sports' },
                { id: 'SUB-006', participant: 'Emily Taylor', activity: 'Art Exhibition', date: '2023-10-10', status: 'approved', category: 'Cultural' },
                { id: 'SUB-007', participant: 'James Wilson', activity: 'Coding Bootcamp', date: '2023-10-09', status: 'rejected', category: 'Technical' }
            ],
            participants: [
                { id: 'P-1001', name: 'Alex Johnson', email: 'alex.j@example.com', phone: '+1 234 567 890', department: 'Computer Science', activities: 3, status: 'active' },
                { id: 'P-1002', name: 'Maria Garcia', email: 'maria.g@example.com', phone: '+1 345 678 901', department: 'Literature', activities: 2, status: 'pending' },
                { id: 'P-1003', name: 'Raj Patel', email: 'raj.p@example.com', phone: '+1 456 789 012', department: 'Engineering', activities: 5, status: 'active' },
                { id: 'P-1004', name: 'Sarah Kim', email: 'sarah.k@example.com', phone: '+1 567 890 123', department: 'Music', activities: 1, status: 'rejected' },
                { id: 'P-1005', name: 'David Chen', email: 'david.c@example.com', phone: '+1 678 901 234', department: 'Sports', activities: 4, status: 'active' }
            ],
            files: [
                { name: 'Robotics_Proposal.pdf', type: 'PDF', size: '2.4 MB', date: '2023-10-15' },
                { name: 'Debate_Team_List.xlsx', type: 'Excel', size: '1.1 MB', date: '2023-10-14' },
                { name: 'Hackathon_Results.docx', type: 'Word', size: '3.2 MB', date: '2023-10-13' },
                { name: 'Music_Festival_Photos.zip', type: 'ZIP', size: '15.7 MB', date: '2023-10-12' },
                { name: 'Sports_Day_Schedule.pdf', type: 'PDF', size: '0.8 MB', date: '2023-10-11' },
                { name: 'Art_Exhibition_Entries.jpg', type: 'Image', size: '8.3 MB', date: '2023-10-10' },
                { name: 'Bootcamp_Certificate_Template.docx', type: 'Word', size: '1.5 MB', date: '2023-10-09' }
            ]
        };

        // DOM Elements
        const navItems = document.querySelectorAll('.nav-item');
        const sections = document.querySelectorAll('.dashboard');
        const menuToggle = document.querySelector('.menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        const recentSubmissionsTable = document.getElementById('recent-submissions');
        const allSubmissionsTable = document.getElementById('all-submissions');
        const participantsTable = document.getElementById('participants-table');
        const filesContainer = document.getElementById('files-container');
        const viewAllLinks = document.querySelectorAll('.view-all');
        const progressBar = document.querySelector('.progress-fill');

        // Initialize the dashboard
        document.addEventListener('DOMContentLoaded', () => {
            renderRecentSubmissions();
            renderAllSubmissions();
            renderParticipantsTable();
            renderFiles();
            setupEventListeners();
            
            // Animate progress bar on load
            setTimeout(() => {
                progressBar.style.width = '85%';
            }, 300);
        });

        // Setup all event listeners
        function setupEventListeners() {
            // Navigation
            navItems.forEach(item => {
                item.addEventListener('click', () => {
                    const target = item.getAttribute('data-target');
                    showSection(target);
                    
                    // Update active nav item
                    navItems.forEach(i => i.classList.remove('active'));
                    item.classList.add('active');
                });
            });

            // View All links
            viewAllLinks.forEach(link => {
                link.addEventListener('click', () => {
                    const target = link.getAttribute('data-target');
                    showSection(target);
                    
                    // Update active nav item
                    navItems.forEach(i => i.classList.remove('active'));
                    document.querySelector(`.nav-item[data-target="${target}"]`).classList.add('active');
                });
            });

            // Mobile menu toggle
            menuToggle.addEventListener('click', () => {
                sidebar.style.width = sidebar.style.width === '280px' ? '0' : '280px';
            });

            // Download file simulation
            document.addEventListener('click', (e) => {
                if (e.target.classList.contains('file-download') || e.target.closest('.file-download')) {
                    const button = e.target.closest('.file-download');
                    const fileName = button.parentElement.parentElement.querySelector('.file-name').textContent;
                    simulateFileDownload(fileName);
                }
            });
        }

        // Show a specific section and hide others
        function showSection(sectionId) {
            sections.forEach(section => {
                section.classList.add('hidden');
            });
            document.getElementById(sectionId).classList.remove('hidden');
            
            // Scroll to top when changing sections
            window.scrollTo(0, 0);
        }

        // Render recent submissions table (only first 5)
        function renderRecentSubmissions() {
            recentSubmissionsTable.innerHTML = '';
            
            mockData.submissions.slice(0, 5).forEach(sub => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="font-medium">${sub.id}</td>
                    <td>${sub.participant}</td>
                    <td>${sub.activity}</td>
                    <td>${sub.date}</td>
                    <td><span class="status status-${sub.status}">${formatStatus(sub.status)}</span></td>
                    <td>
                        <div class="action-btn download" title="Download">
                            <i class="fas fa-download"></i>
                        </div>
                        <div class="action-btn view" title="View Details">
                            <i class="fas fa-eye"></i>
                        </div>
                    </td>
                `;
                recentSubmissionsTable.appendChild(row);
            });
        }

        // Render all submissions table
        function renderAllSubmissions() {
            allSubmissionsTable.innerHTML = '';
            //you have keen eyes I guess...... :) It's made by me: Abdur Rahman Toha
            
            mockData.submissions.forEach(sub => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="font-medium">${sub.id}</td>
                    <td>${sub.participant}</td>
                    <td>${sub.activity}</td>
                    <td>${sub.category}</td>
                    <td>${sub.date}</td>
                    <td><span class="status status-${sub.status}">${formatStatus(sub.status)}</span></td>
                    <td>
                        <div class="action-btn download" title="Download">
                            <i class="fas fa-download"></i>
                        </div>
                        <div class="action-btn view" title="View Details">
                            <i class="fas fa-eye"></i>
                        </div>
                        <div class="action-btn delete" title="Delete">
                            <i class="fas fa-trash"></i>
                        </div>
                    </td>
                `;
                allSubmissionsTable.appendChild(row);
            });
        }

        // Render participants table
        function renderParticipantsTable() {
            participantsTable.innerHTML = '';
            
            mockData.participants.forEach(participant => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="font-medium">${participant.id}</td>
                    <td>${participant.name}</td>
                    <td>${participant.email}</td>
                    <td>${participant.phone}</td>
                    <td>${participant.department}</td>
                    <td>${participant.activities}</td>
                    <td><span class="status status-${participant.status}">${formatStatus(participant.status)}</span></td>
                `;
                participantsTable.appendChild(row);
            });
        }

        // Render files grid
        function renderFiles() {
            filesContainer.innerHTML = '';
            
            mockData.files.forEach(file => {
                const fileCard = document.createElement('div');
                fileCard.className = 'file-card';
                fileCard.innerHTML = `
                    <div class="file-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="file-info">
                        <div class="file-name">${file.name}</div>
                        <div class="file-meta">
                            <span>${file.type}</span>
                            <span>${file.size}</span>
                        </div>
                        <div class="file-meta">
                            <span>Uploaded: ${file.date}</span>
                        </div>
                        <div class="file-actions">
                            <button class="file-download">
                                <i class="fas fa-download"></i> Download
                            </button>
                        </div>
                    </div>
                `;
                filesContainer.appendChild(fileCard);
            });
        }

        // Format status text
        function formatStatus(status) {
            return status.charAt(0).toUpperCase() + status.slice(1);
        }

        // Simulate file download
        function simulateFileDownload(fileName) {
            // Show notification
            const notification = document.createElement('div');
            notification.innerHTML = `
                <div style="
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: #4361ee;
                    color: white;
                    padding: 12px 24px;
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                    z-index: 1000;
                    animation: slideIn 0.3s forwards, fadeOut 0.5s 2.5s forwards;
                ">
                    <i class="fas fa-download"></i> Preparing ${fileName}
                </div>
            `;
            document.body.appendChild(notification);
            
            // Simulate download process
            setTimeout(() => {
                notification.innerHTML = `
                    <div style="
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        background: #2ec4a5;
                        color: white;
                        padding: 12px 24px;
                        border-radius: 8px;
                        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                        z-index: 1000;
                        animation: slideIn 0.3s forwards, fadeOut 0.5s 2.5s forwards;
                    ">
                        <i class="fas fa-check-circle"></i> ${fileName} downloaded successfully!
                    </div>
                `;
                
                // Remove notification after animation
                setTimeout(() => {
                    notification.remove();
                }, 3000);
            }, 1000);
        }

        // API handling functions (mock implementation)
        function apiGet(endpoint) {
            return new Promise((resolve) => {
                setTimeout(() => {
                    console.log(`GET request to ${endpoint}`);
                    
                    // Return mock data based on endpoint
                    let data;
                    switch(endpoint) {
                        case '/api/submissions':
                            data = mockData.submissions;
                            break;
                        case '/api/participants':
                            data = mockData.participants;
                            break;
                        case '/api/files':
                            data = mockData.files;
                            break;
                        default:
                            data = null;
                    }
                    
                    resolve({ success: true, data });
                }, 300);
            });
        }

        function apiPost(endpoint, payload) {
            return new Promise((resolve) => {
                setTimeout(() => {
                    console.log(`POST request to ${endpoint} with data:`, payload);
                    resolve({ success: true, message: 'Operation successful' });
                }, 500);
            });
        }

        // Example API usage
        async function loadDashboardData() {
            try {
                const submissions = await apiGet('/api/submissions');
                const participants = await apiGet('/api/participants');
                const files = await apiGet('/api/files');
                
                // Update UI with fetched data
                if (submissions.success) mockData.submissions = submissions.data;
                if (participants.success) mockData.participants = participants.data;
                if (files.success) mockData.files = files.data;
                
                renderRecentSubmissions();
                renderAllSubmissions();
                renderParticipantsTable();
                renderFiles();
            } catch (error) {
                console.error('Error loading dashboard data:', error);
            }
        }